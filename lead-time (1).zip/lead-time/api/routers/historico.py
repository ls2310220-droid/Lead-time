from fastapi import APIRouter
from api.models.schemas import HistoricoCreate
import api.services.historico as svc

router = APIRouter()

@router.get("/{carregamento_id}")
def listar(carregamento_id: int):
    return svc.listar_por_carregamento(carregamento_id)

@router.post("/{carregamento_id}")
def adicionar(carregamento_id: int, body: HistoricoCreate):
    return svc.adicionar(carregamento_id, body)

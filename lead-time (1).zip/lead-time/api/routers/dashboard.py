from fastapi import APIRouter
from api.db.client import get_db

router = APIRouter()

@router.get("/kpis")
def kpis(semana: int = None):
    db = get_db()
    q = db.table("carregamentos").select("*")
    if semana:
        q = q.eq("semana", semana)
    rows = q.execute().data

    total = len(rows)
    liberados = sum(1 for r in rows if r.get("lib"))
    sem_pv    = sum(1 for r in rows if not r.get("pv"))
    total_pallets = sum(r.get("pallets") or 0 for r in rows)

    return {
        "total": total,
        "liberados": liberados,
        "sem_pv": sem_pv,
        "total_pallets": total_pallets,
        "pct_liberados": round((liberados / total * 100) if total else 0, 1)
    }

# Lead Time — Sistema de Controle de Expedição

Sistema de rastreamento de lead time para expedição de frutas, com IA integrada.

## Deploy em 3 passos

### Passo 1 — Criar tabelas no Supabase
1. Acesse [supabase.com](https://supabase.com) → seu projeto
2. Menu esquerdo → **Editor SQL**
3. Cole o conteúdo de `supabase/migrations/001_initial_schema.sql` e clique em **Run**

### Passo 2 — Deploy na Vercel
1. Crie um repositório no GitHub chamado `lead-time`
2. Faça upload desta pasta
3. Acesse [vercel.com](https://vercel.com) → New Project → importe o repositório
4. Adicione as variáveis de ambiente:
   - `SUPABASE_URL` = URL do seu projeto Supabase
   - `SUPABASE_SERVICE_KEY` = chave service_role do Supabase
   - `ANTHROPIC_API_KEY` = sua chave da Anthropic

### Passo 3 — Testar
Abra a URL gerada pela Vercel. O sistema carrega dados do Supabase em tempo real.

## Estrutura
```
api/           → Backend FastAPI (Python)
  routers/     → Endpoints REST
  services/    → Lógica de negócio
  db/          → Conexão Supabase
  models/      → Schemas Pydantic
public/        → Frontend HTML
supabase/      → SQL de migração
```

## Variáveis de Ambiente
Nunca commite o arquivo `.env` — ele está no `.gitignore`.
